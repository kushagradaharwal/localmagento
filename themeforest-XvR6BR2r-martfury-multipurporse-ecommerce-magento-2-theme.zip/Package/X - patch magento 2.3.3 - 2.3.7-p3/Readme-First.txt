(If you are using Magento 2.4.0 and latest, ignore this)
If you are using Magento 2.3.3 - 2.3.7-p3, you need to upload and extract this patch (override):
- patch magento 2.3.3 - 2.3.7-p3.zip