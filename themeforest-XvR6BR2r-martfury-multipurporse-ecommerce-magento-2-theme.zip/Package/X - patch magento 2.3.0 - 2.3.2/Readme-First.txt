(If you are using Magento 2.3.3 and latest, ignore this)
If you are using Magento 2.3.0 - 2.3.2, you need to upload and extract this patch (override):
- patch magento 2.3.0 - 2.3.2.zip