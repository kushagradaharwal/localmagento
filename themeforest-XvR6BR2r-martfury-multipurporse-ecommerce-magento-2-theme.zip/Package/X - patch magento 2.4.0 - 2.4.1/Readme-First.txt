(If you are using Magento 2.4.2 and latest, ignore this)
If you are using Magento 2.4.0 - 2.4.1, you need to upload and extract this patch (override):
- patch magento 2.4.0 - 2.4.1.zip