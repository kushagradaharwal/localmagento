<?php

namespace MageBig\MbFrame\Plugin\LoginAsCustomer\Model;

class AuthenticateCustomerBySecret
{

}
