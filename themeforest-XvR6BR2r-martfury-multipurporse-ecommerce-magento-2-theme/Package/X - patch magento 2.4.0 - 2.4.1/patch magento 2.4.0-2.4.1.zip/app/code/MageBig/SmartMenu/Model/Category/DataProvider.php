<?php
/**
 * Copyright © magebig.com - All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace MageBig\SmartMenu\Model\Category;

/**
 * Class DataProvider.
 *
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class DataProvider extends \Magento\Catalog\Model\Category\DataProvider
{
    /**
     * @return array
     */
    protected function getFieldsMap()
    {
        $fields = parent::getFieldsMap();

        $fields['smartmenu'] = [
            'smartmenu_show_on_cat',
            'smartmenu_cat_target',
            'smartmenu_cat_style',
            'smartmenu_cat_position',
            'smartmenu_cat_dropdown_width',
            'smartmenu_cat_column',
            'smartmenu_block_right',
            'smartmenu_block_left',
            'smartmenu_static_right',
            'smartmenu_static_left',
            'smartmenu_static_top',
            'smartmenu_static_bottom',
            'smartmenu_cat_label',
            'smartmenu_cat_icon',
            'smartmenu_cat_imgicon',
        ];

        return $fields;
    }
}
